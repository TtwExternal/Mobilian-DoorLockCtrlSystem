//----------------------------------------------------------------------------------------------------;
//var fileNm = "js/use_template/bootstrapAngularAdminWebApp_2_0_0/window.use_template.bootstrapAngularAdminWebApp_2_0_0.initialize.js";
//if( console ) console.log( "[ S ] - " + fileNm + "----------" );
//----------------------------------------------------------------------------------------------------;

/**
 * bootstrapAngularAdminWebApp_2_0_0에서 필요한 Libraries들을 Import 한다.
 * HTML에 존재하는 <script>를 가져와서 로딩한다.
 * @function
 * @param {HTMLElement} t element
 */
window.use_template.bootstrapAngularAdminWebApp_2_0_0.initialize = function( t )
{
	//window.Rh2Log.timeStamp( "---- [ S ] - window.use_template.bootstrapAngularAdminWebApp_2_0_0.initialize():void----------" );

	if( !window.use_template.bootstrapAngularAdminWebApp_2_0_0._bInitialized )
	{
		window.b2link.util.importJS( "./templates/limitless/1.6-BrandPortal/import-js.js" );
		window.use_template.bootstrapAngularAdminWebApp_2_0_0._bInitialized = true;
	}

	//HTML에 존재하는 <script>를 가져와서 로딩한다.;
	window.use_template.bootstrapAngularAdminWebApp_2_0_0.importJSsFromScriptElement__Reuse( t );

	//window.Rh2Log.timeStamp( "---- [ E ] - window.use_template.bootstrapAngularAdminWebApp_2_0_0.initialize():void----------" );
};
window.use_template.bootstrapAngularAdminWebApp_2_0_0._bInitialized = false;

//----------------------------------------------------------------------------------------------------;
//if( console ) console.log( "[ E ] - " + fileNm + "----------" );
//----------------------------------------------------------------------------------------------------;