//----------------------------------------------------------------------------------------------------;
//var fileNm = "js/use_template/bootstrapAngularAdminWebApp_2_0_0/window.use_template.bootstrapAngularAdminWebApp_2_0_0.importJSsFromScriptElement__Reuse.js";
//if( console ) console.log( "[ S ] - " + fileNm + "----------" );
//----------------------------------------------------------------------------------------------------;

/**
 * HTML에 존재하는 <script>를 가져와서 로딩한다.
 * @function
 * @param {HTMLElement} t element
 */
window.use_template.bootstrapAngularAdminWebApp_2_0_0.importJSsFromScriptElement__Reuse = function( t )
{
	//window.Rh2Log.timeStamp( "---- [ S ] - window.use_template.bootstrapAngularAdminWebApp_2_0_0.importJSsFromScriptElement__Reuse():void----------" );

	//var _commonPath = window.use_template.bootstrapAngularAdminWebApp_2_0_0.CONST.PATH_ASSETS;

	var f0 = window.use_template.bootstrapAngularAdminWebApp_2_0_0.importJS__Reuse;
	var a = t.getElementsByTagName( "script" );
	if( !a ) return;
	var i=0, iLen=a.length;
	for( ; i<iLen; ++i )
	{
		try
		{
			//f0( _commonPath + a[ i ].src );
			f0( a[ 0 ].src );
			a[ 0 ].remove();
		}
		catch( e )
		{
			window.Rh2Log.error( "window.use_template.bootstrapAngularAdminWebApp_2_0_0.importJSsFromScriptElement__Reuse Error : " + e );
			debugger;
		}
	}

	//window.Rh2Log.timeStamp( "---- [ E ] - window.use_template.bootstrapAngularAdminWebApp_2_0_0.importJSsFromScriptElement__Reuse():void----------" );
};

//----------------------------------------------------------------------------------------------------;
//if( console ) console.log( "[ E ] - " + fileNm + "----------" );
//----------------------------------------------------------------------------------------------------;