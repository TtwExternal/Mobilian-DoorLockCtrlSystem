//----------------------------------------------------------------------------------------------------;
//var fileNm = "js/use_template/bootstrapAngularAdminWebApp_2_0_0/window.use_template.bootstrapAngularAdminWebApp_2_0_0.initialize.js";
//if( console ) console.log( "[ S ] - " + fileNm + "----------" );
//----------------------------------------------------------------------------------------------------;

/**
 * @property {Object}
 */
window.use_template.bootstrapAngularAdminWebApp_2_0_0.CONST = window.use_template.bootstrapAngularAdminWebApp_2_0_0.CONST || {};

/**
 * @property {String}
 */
window.use_template.bootstrapAngularAdminWebApp_2_0_0.CONST.PATH_ASSETS = "./templates/BootstrapAngularAdminWebApp/2.0.0/html/";

//----------------------------------------------------------------------------------------------------;
//if( console ) console.log( "[ E ] - " + fileNm + "----------" );
//----------------------------------------------------------------------------------------------------;